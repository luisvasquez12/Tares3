#include<iostream>
#include<vector>
#include"luis.h"

using namespace std;

int main()
{
    int count;
    int busquedas;
    int n;
    int metodo = 0;

    //Creamos isntancias para BusquedaOrdenamiento
    BusquedaOrdenamiento <int> BO;
    cout << "Ingrese el tamaño del arreglo: " << endl;
    cin >> count;
    vector <int> elementos;
    cout << "¿cuantas busquedas desea realizar?" << endl;
    cin >> busquedas;
    for(int i = 0; i < busquedas; i++)
    {
        for(size_t i = 0; i < count; i++)
        {
            elementos.push_back(rand()%count);
        }
        cout << "Unsorted" << endl;
        BO.print_vector(elementos, count);
        cout << "¿Que entero desea buscar?" << endl;
        cin >> n;
        cout << "El indice en el que esta el entero por busqueda secuencial es: " << BO.busqSecuencial(n, elementos) << endl;
        bool validacion = false;
        while(validacion == false)
        {
            cout << "¿Que metodo de ordenmaiento desea utilizar?" << endl;
            cout << "1.Insertion Sort" << endl;
            cout << "2.Bubble Sort" << endl;
            cout << "3.Quick Sort" << endl;
            cin >> metodo;
            if(metodo > 0 and metodo <= 3)
            {
                validacion = true;
            }
        }
        if(metodo == 1)
        {
            BO.OrdenaInsercion(elementos);
        }
        if(metodo == 2)
        {
            BO.OrdenaBurbuja(elementos);      
        }
        if(metodo == 3)
        {
            BO.ordenaQuick(elementos, 0, elementos.size()-1);
        }
        cout << "sorted" << endl;
        BO.print_vector(elementos, count);
        cout << "El indice en el que esta el entero por busqueda binaria es: " << BO.busqBinaria(n, elementos, 0, elementos.size()) << endl;
        elementos.clear();
    }
}